import json
import socket
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from netops import load_inventory, probe, main


class InventoryTests(unittest.TestCase):
    def read(self, data):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'inventory.json'
            path.write_text(json.dumps(data), encoding='utf-8')
            return load_inventory(path)

    def test_valid(self):
        data = [{'host': 'localhost', 'ports': [80, 443]}]
        self.assertEqual(self.read(data), data)

    def test_invalid(self):
        for data in ([], {}, [None], [{'host': '', 'ports': [80]}],
                     [{'host': 'localhost', 'ports': [0]}],
                     [{'host': 'localhost', 'ports': [True]}],
                     [{'host': 'localhost', 'ports': [80, 80]}]):
            with self.subTest(data=data), self.assertRaises(ValueError):
                self.read(data)

    def test_missing_file(self):
        with tempfile.TemporaryDirectory() as directory:
            self.assertEqual(main([str(Path(directory) / 'absent.json')]), 2)


class ProbeTests(unittest.TestCase):
    def test_loopback(self):
        with socket.socket() as server:
            server.bind(('127.0.0.1', 0))
            server.listen(1)
            result = probe('127.0.0.1', server.getsockname()[1])
            self.assertEqual(result['status'], 'ok')
            self.assertEqual(result['peer'], '127.0.0.1')

    def test_dns_failure(self):
        with patch('netops.socket.create_connection', side_effect=socket.gaierror('lookup failed')):
            self.assertEqual(probe('example.invalid', 443)['status'], 'dns_error')

    def test_timeout(self):
        with patch('netops.socket.create_connection', side_effect=TimeoutError):
            self.assertEqual(probe('localhost', 443)['status'], 'timeout')

    def test_refused(self):
        with patch('netops.socket.create_connection', side_effect=ConnectionRefusedError):
            self.assertEqual(probe('localhost', 443)['status'], 'refused')

    def test_other_error(self):
        with patch('netops.socket.create_connection', side_effect=OSError('unreachable')):
            self.assertEqual(probe('localhost', 443)['status'], 'connection_error')


if __name__ == '__main__':
    unittest.main()
